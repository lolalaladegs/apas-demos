package com.example.demo.service.implementation;

import com.example.demo.dto.Todo;
import com.example.demo.service.TodoService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
public class TodoServiceRestClient implements TodoService {

    private final WebClient webClient;

    public TodoServiceRestClient(WebClient.Builder webClientBuilder,
            @Value("${service.todo.baseUrl}") String baseUrl) {
        this.webClient = webClientBuilder.baseUrl(baseUrl).build();
    }

    @Override
    public List<Todo> getAllTodoList() {
        return webClient.get()
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<Todo>>() {})
                .block();
    }

    @Override
    public List<Todo> getTodoListOfUser(Integer userId) {
        return webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .queryParam("userId", userId)
                        .build())
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<Todo>>() {})
                .block();
    }
}
