package io.argos.sftp.demo.constant;

import java.time.format.DateTimeFormatter;

public class Constant {

	private Constant() {}
	
	public static final DateTimeFormatter DT_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd-hhmmss");
}
