package com.example.demo.controller;

import com.example.demo.dto.Todo;
import com.example.demo.dto.User;
import com.example.demo.exception.ErrorResponse;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.service.TodoService;
import com.example.demo.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class UserTodoController {

    private static final Logger log = LoggerFactory.getLogger(UserTodoController.class);

    private final UserService userService;
    private final TodoService todoService;

    public UserTodoController(UserService userService, TodoService todoService) {
        this.userService = userService;
        this.todoService = todoService;
    }

    @GetMapping(path = "/users/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public User getUser(@PathVariable("userId") int userId) {
        log.info("Retrieving user with userId={}", userId);
        return userService.getUser(userId);
    }

    @GetMapping(path = "/todos", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Todo> getAllTodoList() {
        log.info("Retrieving all todo list of all users");
        return todoService.getAllTodoList();
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleUserNotFound(Exception e) {
        log.error(e.getMessage(), e);
        ErrorResponse errorResponse = new ErrorResponse(HttpStatus.NOT_FOUND.getReasonPhrase(),
                e.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
    }
}
