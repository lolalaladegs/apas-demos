package sg.gov.cpf.beacon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeaconSpringBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
