package io.argos.sftp.demo.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;

@Configuration
public class SftpConfiguration {

	@Bean
	public DefaultSftpSessionFactory defaultSftpSessionFactory(
			@Value("${sftp.host}") String host,
			@Value("${sftp.port}") int port,
			@Value("${sftp.allowUnknownKeys}") boolean allowUnknownKeys,
			@Value("${sftp.user}") String user,
			@Value("${sftp.password}") String password) {
		DefaultSftpSessionFactory factory = new DefaultSftpSessionFactory();
		factory.setHost(host);
		factory.setPort(port);
		factory.setAllowUnknownKeys(allowUnknownKeys);
		factory.setUser(user);
		factory.setPassword(password);

		return factory;
	}
}
