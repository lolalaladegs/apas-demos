package com.example.demo.service.implementation;

import com.example.demo.dto.Todo;
import com.example.demo.dto.User;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.TodoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;

class UserServiceImplTest {

    // Mocked objects
    @Mock
    private UserRepository userRepository;

    @Mock
    private TodoService todoService;

    // Class under test
    @InjectMocks
    private UserServiceImpl userService;

    @BeforeEach
    void setUp() {
        /*
         * If not using Mockito annotation, initialization can be done manually
         */
//        userRepository = Mockito.mock(UserRepository.class);
//        todoService = Mockito.mock(TodoService.class);
//
//        userService = new UserServiceImpl(userRepository, todoService);

        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getUserTest_whenSuccessfullyRetrieveUser_thenReturnUser() {
        // --- Given ---
        int userId = 1;

        User user = new User(userId, "John", new ArrayList<>());
        given(userRepository.findById(anyInt())).willReturn(Optional.of(user));

        /*
         * Alternatively, when(...).thenReturn(...) can be used instead.
         * given(...).willReturn(...) is used here since it's much more
         * readable given that the test method is structure in
         * given-when-then
         *
         */
//        when(userRepository.findById(anyInt())).thenReturn(user);

        List<Todo> todoList = Arrays.asList(new Todo(1, userId, "Code", false));
        given(todoService.getTodoListOfUser(anyInt())).willReturn(todoList);

        // --- When ---
        User actual = userService.getUser(userId);

        // --- Then ---
        assertEquals(user, actual);
        assertEquals(todoList, actual.getTodo());

    }

    @Test
    void getUserTest_whenUserNot_thenThrowUserNotFoundException() {
        // --- Given ---
        int userId = 1;

        given(userRepository.findById(anyInt())).willReturn(null);


        // --- When ---
        UserNotFoundException actualException = assertThrows(UserNotFoundException.class,
                () -> userService.getUser(userId));

        // --- Then ---
        assertEquals("User not found.", actualException.getMessage());

    }
}