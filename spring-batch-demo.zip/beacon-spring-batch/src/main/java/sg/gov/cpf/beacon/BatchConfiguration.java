package sg.gov.cpf.beacon;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import sg.gov.cpf.beacon.entity.Customer;
import sg.gov.cpf.beacon.processor.JobCompletionNotificationListener;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	@Bean
	public Job job(JobCompletionNotificationListener listener, JobBuilderFactory jobBuilderFactory, Step step) {

		return jobBuilderFactory.get("ETL-Load").incrementer(new RunIdIncrementer()).listener(listener).start(step)
				.build();
	}

	@Bean
	public Step step(StepBuilderFactory stepBuilderFactory, ItemReader<Customer> itemReader,
			ItemProcessor<Customer, Customer> itemProcessor, ItemWriter<Customer> itemWriter) {

		return stepBuilderFactory.get("ETL-file-load").<Customer, Customer>chunk(100).reader(itemReader)
				.processor(itemProcessor).writer(itemWriter).build();
	}

	@Bean
	public FlatFileItemReader<Customer> fileItemReader(@Value("${input}") Resource resource) {

		FlatFileItemReader<Customer> flatFileItemReader = new FlatFileItemReader<>();
		flatFileItemReader.setResource(resource);
		flatFileItemReader.setName("CSV Reader");
		flatFileItemReader.setLinesToSkip(1);

		flatFileItemReader.setLineMapper(lineMapper());

		return flatFileItemReader;
	}

	@Bean
	public LineMapper<Customer> lineMapper() {
		DefaultLineMapper<Customer> defaultLineMapper = new DefaultLineMapper<>();
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setDelimiter(",");

		lineTokenizer.setNames(new String[] { "firstName", "lastName", "loanableAmount", "terms", "loanTypeNo" });

		BeanWrapperFieldSetMapper<Customer> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(Customer.class);

		defaultLineMapper.setLineTokenizer(lineTokenizer);
		defaultLineMapper.setFieldSetMapper(fieldSetMapper);

		return defaultLineMapper;
	}

}
