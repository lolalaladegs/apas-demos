package com.example.demo.service.implementation;

import com.example.demo.dto.Todo;
import com.example.demo.dto.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TodoServiceRestClientTest {

    static MockWebServer todoServiceServer;
    static ObjectMapper mapper;

    TodoServiceRestClient todoServiceRestClient;

    @BeforeAll
    static void beforeAll() throws IOException {
        todoServiceServer = new MockWebServer();
        todoServiceServer.start();
        mapper = new ObjectMapper();
    }

    @BeforeEach
    void setUp() {
        String baseUrl = todoServiceServer.url("/").toString();
        todoServiceRestClient = new TodoServiceRestClient(WebClient.builder(), baseUrl);
    }

    @AfterAll
    static void afterAll() throws IOException {
        todoServiceServer.shutdown();
    }

    @Test
    void getTodoListOfUser_whenTodoListExist_thenReturnStatusCode200AndTodoList() throws JsonProcessingException {
        // --- Given ---
        int userId = 3;

        // Mock endpoint response
        List<Todo> userTodoList = Arrays.asList(
                new Todo(1, userId, "Create todo list", true),
                new Todo(2, userId, "Create another todo list", false));

        MockResponse response = new MockResponse()
                .setResponseCode(HttpStatus.OK.value())
                .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .setBody(mapper.writeValueAsString(userTodoList));

        todoServiceServer.enqueue(response);

        // --- When ---
        List<Todo> actual = todoServiceRestClient.getTodoListOfUser(userId);

        // --- Then ---
        assertEquals(userTodoList, actual);
    }
}