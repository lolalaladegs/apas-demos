package io.argos.sftp.demo.upload;

import java.io.File;

import org.springframework.integration.annotation.Gateway;
import org.springframework.integration.annotation.MessagingGateway;

@MessagingGateway
public interface UploadMessagingGateway {

	@Gateway(requestChannel = "uploadfile")
	public void uploadFile(File file);
}
