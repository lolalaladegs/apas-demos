package io.argos.sftp.demo.download;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.sftp.filters.SftpSimplePatternFileListFilter;
import org.springframework.integration.sftp.inbound.SftpInboundFileSynchronizer;
import org.springframework.integration.sftp.inbound.SftpInboundFileSynchronizingMessageSource;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;

@Configuration
public class SftpTextFileSynchConfiguration {

	private static final Logger log = LoggerFactory.getLogger(SftpTextFileSynchConfiguration.class);
	
	@Bean(name = "textFileSynchronizer")
	public SftpInboundFileSynchronizer textFileSynchronizer(DefaultSftpSessionFactory factory) {
		SftpInboundFileSynchronizer synchornizer = new SftpInboundFileSynchronizer(factory);
		
//		synchornizer.setDeleteRemoteFiles(true);
		synchornizer.setRemoteDirectory("/upload/done");
		synchornizer.setFilter(new SftpSimplePatternFileListFilter("*.txt"));
		
		return synchornizer;
	}
	
	@Bean(name = "sftpTextMessageSource")
	@InboundChannelAdapter(channel = "ingressChannel", poller = @Poller(fixedDelay = "5000"))
	public MessageSource<File> sftpTextMessageSource(@Qualifier("textFileSynchronizer") SftpInboundFileSynchronizer fileSynchronizer) {
		SftpInboundFileSynchronizingMessageSource source = new SftpInboundFileSynchronizingMessageSource(fileSynchronizer);
		
		source.setLocalDirectory(new File("./tmp/incoming/txt"));
		source.setAutoCreateLocalDirectory(true);
		source.setMaxFetchSize(-1);
		
		return source;
	}
	
	@ServiceActivator(inputChannel = "ingressChannel")
	public void handleIncomingFile(File file) throws Exception {
		log.info("handleIncomingFile BEGIN: {}", file.getName());
		
		// parse and send data to other services here
		log.info("Processing file...");
		
		log.info("handleIncomingFile END: {}", file.getName());
	}
}
