package com.example.demo.service;

import com.example.demo.dto.Todo;

import java.util.List;

/**
 * Web service client for <a href="https://jsonplaceholder.typicode.com/todos">Todo API</a>
 */
public interface TodoService {

    List<Todo> getAllTodoList();
    List<Todo> getTodoListOfUser(Integer userId);

}
