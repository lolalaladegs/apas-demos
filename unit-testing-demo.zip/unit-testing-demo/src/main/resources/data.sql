INSERT INTO tbl_user (id, name) VALUES
    (1, 'John'), (2, 'Jane');