package io.argos.sftp.demo.upload;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.argos.sftp.demo.model.Customer;

@RestController
public class UploadController {

	private UploadMessagingGateway gateway;

	@Autowired
	public UploadController(UploadMessagingGateway gateway) {
		super();
		this.gateway = gateway;
	}

	@PostMapping("/upload")
	public String uploadCustomersFile(@RequestBody List<Customer> customers) throws IOException { 

		String content = String.join("\n", customers.stream()
				.map(Customer::toCsv)
				.collect(Collectors.toList()));
		
		File file = new File("./tmp/customers.csv");
		if(file.exists()) file.delete();
		FileUtils.writeStringToFile(file, content, "UTF-8");
		gateway.uploadFile(file);
		
		return "Customer file upload successfully";
	}
}
