package com.example.demo.controller;

import com.example.demo.dto.User;
import com.example.demo.service.TodoService;
import com.example.demo.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.BDDMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

@WebMvcTest(UserTodoController.class)
class UserTodoControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    UserService userService;

    @MockBean
    TodoService todoService;

    @Test
    void getUserTest_whenSuccessfullyRetrievedUser_thenReturnStatusCode200AndUserData() throws Exception {
        // --- Given ---
        int userId = 2;

        // Stub method
        User user = new User(userId, "user", new ArrayList<>());
        BDDMockito.given(userService.getUser(ArgumentMatchers.anyInt())).willReturn(user);

        // --- When ---
        mockMvc.perform(MockMvcRequestBuilders.get("/users/" + userId))

        // --- Then ---
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(userId));
    }

}