package com.example.demo.service.implementation;

import com.example.demo.dto.Todo;
import com.example.demo.dto.User;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.TodoService;
import com.example.demo.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserRepository userRepository;
    private final TodoService todoService;

    public UserServiceImpl(UserRepository userRepository, TodoService todoService) {
        this.userRepository = userRepository;
        this.todoService = todoService;
    }

    @Override
    public User getUser(int userId) {
        User existingUser = userRepository.findById(userId).orElse(null);

        if (existingUser != null) {
            log.info("User found.");
            List<Todo> todoListOfUser = todoService.getTodoListOfUser(userId);
            existingUser.setTodo(todoListOfUser);
        } else {
            log.info("User not found.");
            throw new UserNotFoundException();
        }

        return existingUser;
    }
}
