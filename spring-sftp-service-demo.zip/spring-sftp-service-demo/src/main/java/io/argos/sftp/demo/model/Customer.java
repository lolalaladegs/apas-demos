package io.argos.sftp.demo.model;

public class Customer {

	private long id;
	private String firstName;
	private String lastName;
	private double amount;
	private int terms;
	private int type;
	
	public Customer() {
		super();
	}

	public Customer(long id, String firstName, String lastName, double amount, int terms, int type) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.amount = amount;
		this.terms = terms;
		this.type = type;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getTerms() {
		return terms;
	}

	public void setTerms(int terms) {
		this.terms = terms;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String toCsv() {
		return String.format("%s,%s,%s,%s,%s,%s", id, firstName, lastName, amount, terms, type);
	}
	
	
	
}
