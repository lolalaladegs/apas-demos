package sg.gov.cpf.beacon.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import sg.gov.cpf.beacon.entity.Customer;

@Component
public class CustomerItemProcessor implements ItemProcessor<Customer, Customer> {

	@Override
	public Customer process(Customer customer) throws Exception {
		double interestRate = customer.getLoanTypeNo() == 1 ? .1 : .5; //java ternary
		double monthlyWithoutInterest = customer.getLoanableAmount() / customer.getTerms();
		double monthlyInterest = (customer.getLoanableAmount() / customer.getTerms()) * interestRate;
		double monthlyAmortization = monthlyWithoutInterest + monthlyInterest;

		customer.setMonthlyAmortization(monthlyAmortization);
		
		
		
		return customer;
	}

}
