package sg.gov.cpf.beacon.processor;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import sg.gov.cpf.beacon.CustomerRepository;
import sg.gov.cpf.beacon.entity.Customer;

@Component
public class DatabaseWriter implements ItemWriter<Customer>{
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public void write(List<? extends Customer> customer) throws Exception {
		customerRepository.saveAll(customer);
		
	}

}
