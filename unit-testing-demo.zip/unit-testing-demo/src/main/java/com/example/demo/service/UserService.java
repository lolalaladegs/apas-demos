package com.example.demo.service;

import com.example.demo.dto.User;

public interface UserService {

    User getUser(int userId);
}
