package sg.gov.cpf.beacon;

import org.springframework.data.jpa.repository.JpaRepository;

import sg.gov.cpf.beacon.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

}
