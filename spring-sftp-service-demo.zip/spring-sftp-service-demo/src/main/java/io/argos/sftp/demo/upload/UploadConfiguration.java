package io.argos.sftp.demo.upload;

import static io.argos.sftp.demo.constant.Constant.DT_FORMATTER;

import java.time.LocalDateTime;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.expression.common.LiteralExpression;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.sftp.outbound.SftpMessageHandler;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;
import org.springframework.messaging.MessageHandler;

@Configuration
public class UploadConfiguration {
	
	@Bean
	@ServiceActivator(inputChannel = "uploadfile")
	public MessageHandler uploadHandler(DefaultSftpSessionFactory factory) {
		SftpMessageHandler messageHandler = new SftpMessageHandler(factory);
		messageHandler.setRemoteDirectoryExpression(new LiteralExpression("/upload"));
		messageHandler.setFileNameGenerator(message -> String.format("customers_%s.csv", LocalDateTime.now().format(DT_FORMATTER)));
		return messageHandler;
	}
}
